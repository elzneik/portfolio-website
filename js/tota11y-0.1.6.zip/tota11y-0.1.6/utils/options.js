module.exports = {
    // The name to set as the "jsxPragma" for the babel configs in various
    // parts of the codebase
    jsxPragma: "buildElement",
};
